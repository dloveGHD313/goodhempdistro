"use client";
import AgeGate from "./AgeGate";

export default function AgeGateClient() {
  return <AgeGate />;
}
