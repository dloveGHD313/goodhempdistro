import { NextRequest, NextResponse } from "next/server";
import {
  getAdminDiagnostics,
  getSupabaseAdminClientOrThrow,
  type AdminDiagnostics,
} from "@/lib/supabaseAdmin";
import { requireAdmin } from "@/lib/auth/requireAdmin";
import { revalidatePath } from "next/cache";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

// Build tag to verify deployed code version
const BUILD_TAG = "approve-no-joins-2026-01-20-p4z2n";

type ApproveResponse = {
  ok: boolean;
  diagnostics: AdminDiagnostics & {
    queryName?: string;
    buildTag?: string;
  };
  data?: {
    service?: any;
  };
  // legacy field used by existing client code
  success?: boolean;
  error?: {
    message: string;
    code?: string;
    details?: string;
    hint?: string;
    status?: number;
    queryContext?: string;
  };
};

function createErrorResponse(params: {
  diagnostics: AdminDiagnostics;
  queryContext: string;
  status: number;
  message: string;
  supabaseError?: any;
}): NextResponse<ApproveResponse> {
  const { diagnostics, queryContext, status, message, supabaseError } = params;

  const urlPreview = diagnostics.supabaseUrlUsed?.substring(0, 50) || "NOT_SET";
  console.error(
    `[admin/services/approve] Query failed: ${queryContext} ` +
      `message=${supabaseError?.message || message} ` +
      `code=${supabaseError?.code || "unknown"} ` +
      `url=${urlPreview}... ` +
      `keyType=${diagnostics.keyType} ` +
      `keySource=${diagnostics.keySourceName || "none"} ` +
      `keyLength=${diagnostics.keyLength ?? "unknown"} ` +
      `buildTag=${BUILD_TAG}`
  );

  return NextResponse.json<ApproveResponse>(
    {
      ok: false,
      diagnostics: {
        ...diagnostics,
        queryName: queryContext,
        buildTag: BUILD_TAG,
      },
      error: {
        message,
        code: supabaseError?.code || undefined,
        details: supabaseError?.details || undefined,
        hint: supabaseError?.hint || undefined,
        status,
        queryContext,
      },
    },
    {
      status,
      headers: { "Cache-Control": "no-store" },
    }
  );
}

/**
 * Approve service (admin only)
 */
export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const diagnostics = getAdminDiagnostics();
    const adminCheck = await requireAdmin();
    if (!adminCheck.user) {
      return createErrorResponse({
        diagnostics,
        queryContext: "auth_check",
        status: 401,
        message: "Unauthorized",
      });
    }

    if (!adminCheck.isAdmin) {
      return createErrorResponse({
        diagnostics,
        queryContext: "auth_check",
        status: 403,
        message: "Forbidden: Not an admin",
      });
    }

    const { id } = await params;
    
    let admin;
    try {
      admin = getSupabaseAdminClientOrThrow();
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : "Failed to initialize admin client";
      return createErrorResponse({
        diagnostics,
        queryContext: "admin_client_init",
        status: 500,
        message: errorMessage,
      });
    }

    console.log(
      `[admin/services/approve] Admin client initialized ` +
        `keySource=${diagnostics.keySourceName || "none"} ` +
        `keyType=${diagnostics.keyType} ` +
        `keyLength=${diagnostics.keyLength ?? "unknown"} ` +
        `buildTag=${BUILD_TAG}`
    );

    // Get service
    const { data: service, error: serviceError } = await admin
      .from("services")
      .select("id, name, title, status")
      .eq("id", id)
      .maybeSingle();

    if (serviceError || !service) {
      return createErrorResponse({
        diagnostics,
        queryContext: "service_get",
        status: 404,
        message: serviceError?.message || "Service not found",
        supabaseError: serviceError || undefined,
      });
    }

    if (service.status !== 'pending_review') {
      return createErrorResponse({
        diagnostics,
        queryContext: "status_check",
        status: 400,
        message: `Service is not pending review (current status: ${service.status})`,
      });
    }

    // Update service to approved
    const { data: updatedService, error: updateError } = await admin
      .from("services")
      .update({
        status: 'approved',
        active: true, // Auto-activate on approval
        reviewed_at: new Date().toISOString(),
        reviewed_by: adminCheck.user.id,
        rejection_reason: null, // Clear any previous rejection reason
      })
      .eq("id", id)
      .select("id, name, title, status")
      .single();

    if (updateError) {
      return createErrorResponse({
        diagnostics,
        queryContext: "service_update",
        status: 500,
        message: updateError?.message || "Failed to approve service",
        supabaseError: updateError,
      });
    }

    // Get updated counts after approval
    const { count: pendingCount } = await admin
      .from("services")
      .select("*", { count: "exact", head: true })
      .eq("status", "pending_review");

    const { count: approvedCount } = await admin
      .from("services")
      .select("*", { count: "exact", head: true })
      .eq("status", "approved");

    const urlPreview = diagnostics.supabaseUrlUsed?.substring(0, 50) || "NOT_SET";
    console.log(
      `[admin/services/approve] Approved ${id} (${service.name || service.title}) by admin ${adminCheck.user.id}. ` +
        `pending=${pendingCount ?? 0} approved=${approvedCount ?? 0} ` +
        `url=${urlPreview}... keyType=${diagnostics.keyType} keySource=${diagnostics.keySourceName || "none"} ` +
        `keyLength=${diagnostics.keyLength ?? "unknown"} ` +
        `buildTag=${BUILD_TAG}`
    );

    // Revalidate paths
    revalidatePath("/admin/services");
    revalidatePath("/vendors/services");
    revalidatePath("/services"); // Public listing

    return NextResponse.json<ApproveResponse>(
      {
        ok: true,
        success: true,
        diagnostics: {
          ...diagnostics,
          queryName: "success",
          buildTag: BUILD_TAG,
        },
        data: {
          service: updatedService,
        },
      },
      {
        headers: { "Cache-Control": "no-store" },
      }
    );
  } catch (error) {
    const diagnostics = getAdminDiagnostics();
    const errorMessage = error instanceof Error ? error.message : "Internal server error";
    return createErrorResponse({
      diagnostics,
      queryContext: "unexpected_error",
      status: 500,
      message: errorMessage,
    });
  }
}
